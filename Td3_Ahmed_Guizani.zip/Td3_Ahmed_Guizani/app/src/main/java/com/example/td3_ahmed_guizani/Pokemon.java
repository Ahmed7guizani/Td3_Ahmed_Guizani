package com.example.td3_ahmed_guizani;

public class Pokemon {
    private String name;
    private String url;

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }
}
